#!/usr/bin/env bash
set -euo pipefail

# LOU GAMING OS 64-bit package starter for Ubuntu 24.04-based systems.
# Run from an installed test system or inside a Cubic customization chroot.

if [[ "$(dpkg --print-architecture)" != "amd64" ]]; then
  echo "This profile is intended for 64-bit amd64 systems." >&2
  exit 1
fi

sudo apt update
sudo apt install -y \
  cinnamon-desktop-environment lightdm \
  firefox \
  gamemode mangohud \
  git curl wget unzip p7zip-full \
  htop btop fastfetch \
  gnome-disk-utility gparted \
  network-manager-gnome pavucontrol \
  flatpak

# Steam, Lutris, and Heroic availability depends on enabled repositories and release.
# Keep these separate so the base desktop can still install if one source is unavailable.
echo
cat <<'MSG'
Base packages installed.
For Steam: enable the Ubuntu multiverse repository, then install steam-installer.
For Lutris/Heroic: use their official supported installation instructions for your release.
Verify package availability in the exact ISO build environment before remastering.
MSG
