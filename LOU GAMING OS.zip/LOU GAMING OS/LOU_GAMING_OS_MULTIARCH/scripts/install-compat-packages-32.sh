#!/usr/bin/env bash
set -euo pipefail

# Lightweight compatibility profile for a Debian i386 installation.
# This is not equivalent to the 64-bit gaming edition. Package availability varies.

if [[ "$(dpkg --print-architecture)" != "i386" ]]; then
  echo "This profile is intended for 32-bit i386 systems." >&2
  exit 1
fi

sudo apt update
sudo apt install -y \
  xfce4 xfce4-goodies lightdm \
  firefox-esr \
  git curl wget unzip p7zip-full \
  htop fastfetch \
  gparted pavucontrol network-manager-gnome \
  flatpak

cat <<'MSG'
32-bit compatibility desktop installed.
Modern Steam, current game launchers, GPU drivers and games may be unavailable
or unsupported on i386. Do not advertise this edition as supporting modern PC gaming.
MSG
