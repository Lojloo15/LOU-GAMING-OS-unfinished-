#!/usr/bin/env bash
set -euo pipefail
if ! command -v gamemoderun >/dev/null 2>&1; then
  echo "GameMode is not installed. Install the gamemode package first." >&2
  exit 127
fi
if [[ $# -eq 0 ]]; then
  echo "Usage: gaming-mode.sh command [arguments...]" >&2
  exit 2
fi
exec gamemoderun "$@"
