# LOU GAMING OS Multi-Architecture Installer Source

The planned setup menu is:

- Choose your version
- 32BIT - LOU GAMING OS
- 64BIT - LOU GAMING OS

## Important status
This is installer source/build kit, NOT a finished bootable ISO. The two architecture-specific operating-system installer images are not included, and this environment does not have an ISO mastering/bootloader toolchain available to create and test a bootable hybrid ISO. Do not burn this folder or ZIP expecting it to boot.

## Required input images
Place compatible, tested installer images at:

- `images/lou-gaming-os-32bit.iso`
- `images/lou-gaming-os-64bit.iso`

The GRUB menu is a starting point and may need adaptation to the selected distributions' boot layout; simply loopback-loading an arbitrary ISO is not guaranteed to work. A robust release should extract or chainload each distro's supported boot files and be tested in a VM and on real hardware.

## Architecture note
A 32-bit edition cannot be assumed to be the same OS build as the 64-bit edition. Modern Steam/Proton and many current games have limited or no 32-bit support. Keep the 32-bit edition as a separate compatibility build.
