# Build status

- [x] Architecture-selection menu source authored.
- [x] 32-bit and 64-bit menu entries added.
- [ ] Obtain and configure real 32-bit and 64-bit base installer images.
- [ ] Install ISO mastering tools (e.g. xorriso and GRUB utilities) in a suitable build environment.
- [ ] Build bootable ISO and verify boot catalog / UEFI support.
- [ ] Test both menu paths in a virtual machine and on target hardware.

A ZIP of this source is not an operating-system ISO.
