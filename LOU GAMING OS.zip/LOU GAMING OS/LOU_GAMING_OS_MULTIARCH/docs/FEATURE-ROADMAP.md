# Feature roadmap

- [x] Define 64-bit and 32-bit edition goals
- [x] Starter package scripts
- [x] GameMode launcher helper
- [x] ISO build checklist
- [ ] Integrate and test Windows 7-inspired theme
- [ ] Integrate original animated Plymouth splash
- [ ] Configure installer component selection
- [ ] Build 64-bit ISO with Cubic
- [ ] Build separate 32-bit compatibility ISO
- [ ] Test both ISOs in a VM and on target hardware
- [ ] Publish checksums and known-issues list
