# Build a bootable LOU GAMING OS ISO (64-bit)

## Recommended route

Use a supported Ubuntu 24.04 LTS Desktop ISO and Cubic on a separate Ubuntu machine. The kit does not include Ubuntu's copyrighted/re-distributable installation image, so it cannot be a complete ISO by itself.

1. Download the official Ubuntu 24.04 LTS Desktop ISO from Ubuntu's official website and verify its checksum.
2. Install Cubic using the official Cubic instructions on an Ubuntu host.
3. Start a Cubic project and select the official ISO as the source.
4. In Cubic's terminal environment, add Cinnamon and the packages from `scripts/install-gaming-packages-64.sh`. Adapt `sudo` commands if working inside a root chroot (Cubic's terminal normally runs as root).
5. Add a legally redistributable Windows 7-inspired theme, lime-green LOU branding, and an original Plymouth boot splash. Do not copy Windows system files or logos.
6. Configure the live desktop and installer defaults. Test package availability; Ubuntu package names and repositories can change.
7. Generate the ISO in Cubic.
8. Test it in a VM first, then write it to a spare USB using a trusted imaging tool. Boot and test on target hardware before installing.
9. Verify the ISO checksum and test installation, graphics, audio, network, suspend, updates, and gaming packages.

## Important architecture note

A modern Ubuntu desktop ISO is 64-bit. Do not label a 64-bit ISO as 32-bit. Build the 32-bit compatibility edition separately from a Debian i386 base, using the lightweight script and a suitable installer/remastering workflow. It will have substantially reduced gaming compatibility.

## What's not completed by this kit

No ISO has been generated or tested here. Steam, Lutris, Heroic, drivers, installer component selection, animated boot, and theme integration all require validation in the actual build environment. This is a project scaffold to help produce a real image, not a fake `.iso` renamed from a ZIP.
