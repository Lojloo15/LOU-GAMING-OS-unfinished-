# LOU GAMING OS identity

- Product name: LOU GAMING OS
- Desktop direction: Windows 7-inspired, customisable, classic taskbar/start-menu layout
- Suggested accent: lime green
- Suggested boot splash text: LOU GAMING OS
- Keep visual assets original or appropriately licensed; do not redistribute Windows 7 system files, logos, or copyrighted wallpapers.

A theme is not automatically installed by this starter kit. Add a legally redistributable GTK theme, icon pack, wallpaper, and Plymouth theme during ISO customization, then verify licensing and boot behavior.
